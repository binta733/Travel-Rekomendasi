async function fetchRecommendations() {
    try {
        const response = await fetch('travel_recommendation_api.json');
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error fetching recommendations:', error);
    }
}

function searchRecommendation() {
    const keyword = document.getElementById('search').value.toLowerCase();
    fetchRecommendations().then(() => {
        console.log(`Mencari rekomendasi untuk: ${keyword}`);
    });
}

function resetSearch() {
    document.getElementById('search').value = '';
    document.getElementById('recommendation-results').innerHTML = '';
}
